const mongoose = require('mongoose');

const database_uri = "mongodb://localhost:27017/filop";

const connectDB = async () => {
    try {
        await mongoose.connect(database_uri,{//process.env.DATABASE_URI, {
            useUnifiedTopology: true,
            useNewUrlParser: true
        });
    } catch (err) {
        console.error(err);
    }
}

module.exports = connectDB