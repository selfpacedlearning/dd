const express = require('express');
const router = express.Router();
const path = require('path');

// const User = require('../model/User');
const Option = require('../model/Option');



router.get('^/$|/index(.html)?', (req, res) => {

    // res.sendFile(path.join(__dirname, '..', 'views', 'index.html'));

    // const getAllUsers = async () => {
    //     const users = await User.findOne();
    //     res.render('index', {
    //         data: users
    //     })
    // }

    var Namads=[
        "آساس",
        "ارزش",
        "اهرم",
        "بتهران",
        "برکت",
        "بساما",
        "بهین رو",
        "پترول",
        "توان",
        "جهش",
        "خاور",
        "خبهمن",
        "خپارس",
        "خساپا",
        "خگستر",
        "خودران",
        "خودرو",
        "دریا",
        "دی",
        "ذوب",
        "رویین",
        "سرو",
        "سلام",
        "شبندر",
        "شپنا",
        "شتاب",
        "شستا",
        "فخوز",
        "فرابورس",
        "فصبا",
        "فملی",
        "فولاد",
        "کاریس",
        "کرمان",
        "لبخند",
        "موج",
        "وبصادر",
        "وبملت",
        "وتجارت",
        "وکغدیر",
        "های وب",
        "هم وزن"
      ]
    // var group = ['خودرویی','بانک و بیمه','پالایشی/پترو','فلزات','صندوق','سرمایه‌گذاری','سایر']

    var filterTitles = ['حجم معامله','اهرم فروشنده','درصد اردر فروشنده','% سربه‌سری فروشنده ','% سربه‌سری روزانه ','%تفاوت با منصفانه','تعداد موقعیت','حجم فروش حقوقی','سربه‌سری خریدار',' موقعیت جدید امروز','آخرین حقوقی','']

    
    // Option.find({}, function(err, options){
    //     // console.log("this is: ", options)
    //     res.render('index', {
    //         data: options
    //     })
    // })

    res.render('index', {
        data: Namads,
        filterTitles: filterTitles
    })
        
});

module.exports = router;